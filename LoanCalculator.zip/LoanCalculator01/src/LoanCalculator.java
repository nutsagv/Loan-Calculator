import java.util.Scanner;
import java.lang.Math;
import java.text.NumberFormat;
public class LoanCalculator {
    public static void main(String[] args){
        int i;
        String loan_type;
        double amount, term, interestrate, totalsum, monthlyfee, housemarketvalue, totalsumdepts;
        String[] loantype = new String[] {"Personal_loan", "Auto_loan", "Student_loan", "Mortgage_loan", "Home_equity_loan"};
        Scanner sc = new Scanner(System.in);
        System.out.println("Hello, dear customer!");
        for (i=0; i<10; i++) {
            System.out.print("== ");
        }
        System.out.println();
        System.out.println("Please enter the amount of loan: ");
        amount = sc.nextDouble();

        System.out.println("Dear user, we have the following loan types: ");
        for (i = 0; i<loantype.length; i++){
            System.out.println(loantype[i]);
        }
        System.out.println("Dear user, which loan type would you like to select?");
        loan_type = sc.next();

        System.out.print("Please enter along how many years you would like to pay the loan: ");
        term = sc.nextDouble();
       double numberofpayments = term * 12;

        System.out.print("Please enter the annual interest rate: ");
        interestrate= sc.nextDouble();
        double monthlyInterest = interestrate / 100 / 12;

        if (loan_type.equals("Auto_loan")){
            System.out.println("Dear user, unfortunately, we can not provide a discount for you :)) Instead, we will charge you with extra 2% :))");
            interestrate = interestrate + 2;
            totalsum = amount + amount * (interestrate / 100);
            monthlyfee = totalsum / (term * 12);
            System.out.println("Dear user, your total sum is: " + totalsum);
            System.out.println("Dear user, your monthly fee is: " + monthlyfee);

        }
        else if (loan_type.equals("Personal_loan")){
            System.out.println("Dear user, fortunately, we can provide a 2% discount for you :))");
            if (interestrate-2 < 0) {
                interestrate = 0;
                System.out.println("Dear user, since your interest rate was lower than 0 with our discount included, you will not be charged with any interest rate! :))");
            }
            else {
                interestrate = interestrate - 2;
            }
            totalsum = amount + amount * (interestrate / 100);
            monthlyfee = totalsum / (term * 12);
            System.out.println("Dear user, your total sum is: " + totalsum);
            System.out.println("Dear user, your monthly fee is: " + monthlyfee);
        }
        else if (loan_type.equals("Student_loan")){
            System.out.println("Dear user, fortunately, we can provide a 5% discount for you :))");
            if (interestrate-5 < 0) {
                interestrate = 0;
                System.out.println("Dear user, since your interest rate was lower than 0 with our discount included, you will not be charged with any interest rate! :))");
            }
            else {
                interestrate = interestrate - 5;
            }
            totalsum = amount + amount * (interestrate / 100);
            monthlyfee = totalsum / (term * 12);
            System.out.println("Dear user, your total sum is: " + totalsum);
            System.out.println("Dear user, your monthly fee is: " + monthlyfee);
        }
        else if (loan_type.equals("Mortgage_loan")){
            System.out.println("Dear user, unfortunately, we can not provide a discount for you :))");

            totalsum = amount + amount * (interestrate / 100);
            double mathpower = Math.pow(1 + monthlyInterest, numberofpayments);
            monthlyfee = amount * (monthlyInterest * mathpower / (mathpower - 1));
            String monthlyfeecalculator = NumberFormat.getCurrencyInstance().format(monthlyfee);
            System.out.println("Dear user, your total sum is: " + totalsum);
            System.out.println("Dear user, your monthly fee is: " + monthlyfeecalculator);
        }
        else if (loan_type.equals("Home_equity_loan")){
            System.out.println("Dear user, fortunately, we can provide a 1% discount for you :))");
            System.out.println("Dear user, please enter the current market value of a house: ");
            housemarketvalue = sc.nextDouble();
            System.out.println("Dear user, please enter the total sum of depts: ");
            totalsumdepts = sc.nextDouble();

            if (interestrate-1 < 0) {
                interestrate = 0;
                System.out.println("Dear user, since your interest rate was lower than 0 with our discount included, you will not be charged with any interest rate! :))");
            }
            else {
                interestrate = interestrate - 1;
            }
            totalsum = amount + amount * (interestrate / 100);
            monthlyfee = housemarketvalue - totalsumdepts;
            System.out.println("Dear user, your total sum is: " + totalsum);
            System.out.println("Dear user, your monthly fee is: " + monthlyfee);
        }
        else {
            System.out.println("Dear user, please select the loan type given above! >:(");
            interestrate = 0;
            amount = 0;
            term = 0;
        }

    }

}
